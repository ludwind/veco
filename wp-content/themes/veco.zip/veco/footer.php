<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<footer>
    ™ 2017 Veco. 
</footer>


<?php wp_footer(); ?>



</div><!-- .site -->
			</div> <!-- end #cb-container -->

		</div> <!-- end #cb-outer-container -->


</body>
</html>
